#pragma once
#include <stdint.h>
#include <linux/fb.h>
#define WIDTH 320
#define HEIGTH 240
int fd;

//uint16_t **framebuffer[WIDTH][HEIGTH];
uint16_t *framebuffer;
struct fb_copyarea rect; //fra kompendiet, for å mappe framebufferen til minne, se init

void frameinit(void);
void closefile(void);
/*void writepixel(uint16_t pixel);
void colorpixel(uint16_t pixel);
void drawrectangle(int width,int height,char color);*/
void testscreen(void);

void initDisplay();
void fill_screen(uint16_t value);

void refresh_screen();

void draw_rect(int x, int y, int color);
