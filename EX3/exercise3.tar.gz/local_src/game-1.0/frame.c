#include "pong.h"
#include "font.h"
//#include "efm32gg.h"
#include <linux/fb.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>

#include <stdint.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <math.h>

int fd;
int frame_size;
void frameinit(void){
	//map arrayet framebuffer til minne slik at vi kan skrive direkte med C kode.

	rect.dx=0;
	rect.dy=0;
	rect.width= WIDTH;
	rect.height= HEIGTH;

	frame_size= WIDTH*HEIGTH*2;
 	fd= open("/dev/fb0",O_RDWR);
	if(!fd){

		printf("dev/fb0 IS NOT A DIRECTORY\n");
		exit(0);
	}

	printf("file open\n");
	framebuffer = (uint16_t*)mmap( NULL,frame_size, PROT_READ | PROT_WRITE, MAP_SHARED,fd, 0);

	for(int i=0;i<WIDTH*HEIGTH;i++)
	{
		framebuffer[i]= 0;
	}

	print_col=0;
	print_row=0;

}



void closefile(void){


	
	ioctl(fd,0x4680,&rect);
	printf("file refreshed\n");


	int a = close(fd); 
	if(a == -1){
		printf("Failed to close file\n");
		exit(0);
	}
	printf("filed closed\n");

}








void drawrectangle(int column, int row,int rec_width,int rec_heigth, int color)
{	
	for(int i = column; i < column + rec_width; i++)
	{
		for(int j = row; j < row + rec_heigth; j++)
		{
			framebuffer[i + j * WIDTH] = color;
		}
	}
	
}

void refresh_screen(void){
	ioctl(fd,0x4680,&rect);
}





void print_char(int col, int row, char c){	
	int c2=c-32;
	for (int i=0; i<8; i++){
		for (int j=0; j<8; j++){
			if(((font[c2][i] >> j) & 1) == 0){
				framebuffer[col+i+j*WIDTH+(row*WIDTH)]=0;
			}
			else{
				framebuffer[col+i+j*WIDTH+(row*WIDTH)]=0xFFFF;
			}
		}
	}
}

void print_string(char *str){
	int i = 0;
	while(str[i] != '\0'){
		if(str[i]=='\n'){
			print_col=0;
			print_row=print_row+8;
		}
		else{
			print_char(print_col, print_row, str[i]);
			print_col=print_col+8;
		}
		
		

		if(print_col>WIDTH-8){
			print_row=print_row+8;
			print_col=0;
		}
		//if(print_row>HEIGTH)
		i++;
	}
	//refresh_screen();
}

void set_cursor(int col, int row){
	print_row=row;
	print_col=col;
}

void clear_screen(void){
	for(int i=0;i<WIDTH*HEIGTH;i++)
	{
		framebuffer[i]= 0;
	}
	set_cursor(0,0);
	refresh_screen();
}

void clear_line(int line){
	set_cursor(0,line*8);
	for(int i=0; i<WIDTH*8; i++){
		framebuffer[line*8*WIDTH+i]=0;
	}
	refresh_screen();
}

void print_int(int a){
	char buffer[50];
	sprintf(buffer,"%d",a);
	print_string(buffer);
}

void invert_line(int line){
	set_cursor(0,line*8);
	for(int i=0; i<WIDTH*8; i++){
		if(framebuffer[line*8*WIDTH+i]==0){
			framebuffer[line*8*WIDTH+i]=0xFFFF;
		}
		else{
			framebuffer[line*8*WIDTH+i]=0;
		}
		
	}
	//refresh_screen();
}









