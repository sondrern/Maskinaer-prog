#define _BSD_SOURCE
#pragma once
#include <stdint.h>
#include <linux/fb.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include "frame.h"
int current_x;
	int current_y;
	int last_x;
	int last_y;
	
	int dy;
	int dx;
	
	int l_paddle_x;
	int l_paddle_y;
	
	int r_paddle_x;
	int r_paddle_y;

	int left_dy;
	int right_dy;

	int score1;
	int score2;
	int targetscore;
	int level;
	int gameon;


void init_game(void);

void goal(void);

void updategame(int button);
void compute_game(void);

void cheat_mode(void);
void diff_level(void);
void change_color(void);
void menu(void);
void settings(void);