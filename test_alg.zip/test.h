unsigned int myAdd(unsigned int a, unsigned int b);

unsigned int myMult (unsigned int a, unsigned int b);

unsigned int modolo (unsigned long int t, unsigned int n, unsigned int k);

unsigned int findbit(unsigned int x);
unsigned int blakley(unsigned int a, unsigned int b, unsigned int n);


unsigned int binMethod(unsigned int m, unsigned int e, unsigned int n);

unsigned int modinv(unsigned int u, unsigned int v);


unsigned int evenModExp(unsigned int a, unsigned int e, unsigned int n);


unsigned int monpro(unsigned int x,unsigned int y,unsigned int n, unsigned int n2,unsigned int  r);
unsigned int modexp(unsigned int m, unsigned int e, unsigned int n);

void printbitwise(unsigned int x);

unsigned int montgomery(unsigned int m, unsigned int e, unsigned int n);
unsigned int csa(unsigned int a, unsigned int b, unsigned int n);
unsigned int csa2(unsigned int a, unsigned int b, unsigned int n);
void adder(unsigned int a, unsigned int b, unsigned int *c, unsigned int *s);
unsigned int monpro3(unsigned int x, unsigned int y, unsigned int m);
unsigned int monpro3(unsigned int x, unsigned int y, unsigned int m);

unsigned int modexpimp(unsigned int m, unsigned int e, unsigned int n);

unsigned int monpro_ny(unsigned int a, unsigned int b, unsigned int n);
unsigned int modexp2(unsigned int p, unsigned int e, unsigned int m);